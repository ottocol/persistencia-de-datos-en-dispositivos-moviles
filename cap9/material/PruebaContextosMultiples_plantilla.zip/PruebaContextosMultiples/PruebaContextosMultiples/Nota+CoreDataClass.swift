//
//  Nota+CoreDataClass.swift
//  PruebaContextosMultiples
//
//  Created by Otto Colomina Pardo on 20/1/17.
//  Copyright © 2017 Universidad de Alicante. All rights reserved.
//

import Foundation
import CoreData


public class Nota: NSManagedObject {

}
